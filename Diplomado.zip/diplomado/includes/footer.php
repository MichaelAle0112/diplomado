</main>
    <footer>
        <div class="footer-content">
            <p>&copy; 2023 Sabores del Valle. Todos los derechos reservados.</p>
            <p>Dirección: Valle de los Sabores 123, Ciudad</p>
            <p>Teléfono: +123 456 7890</p>
            <img src="/proyecto-restaurante/images/logo.png" alt="Logo Sabores del Valle" width="50">
            <img src="/proyecto-restaurante/images/restaurante.jpg" alt="Imagen del restaurante Sabores del Valle" class="footer-img">
        </div>
    </footer>
    <script src="../js/scripts.js"></script>
</body>
</html>